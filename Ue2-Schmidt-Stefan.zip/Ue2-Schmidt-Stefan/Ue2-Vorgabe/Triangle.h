//
//  Triangle.h
//  Ue2-Vorgabe
//
//  Created by schlubbi on 23/10/13.
//  Copyright (c) 2013 kjung. All rights reserved.
//

#import "Glyph.h"

@interface Triangle : Glyph

- (void)paint;
- (double)area;
- (double)circumference;
@end
