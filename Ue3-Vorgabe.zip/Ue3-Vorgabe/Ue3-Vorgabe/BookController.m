//
//  BookController.m
//  Ue3-Vorgabe
//
//  Created by Klaus Jung on 31.10.13.
//  Copyright (c) 2013 Klaus Jung. All rights reserved.
//

#import "BookController.h"
#import "IOHelper.h"

@interface BookController()
- (void)enterCard;
- (void)lookupCard;
- (void)printBook;
@end

@implementation BookController

- (void)run {
    // TODO: read in address book from file @"book.archive"
    
    // main loop

    NSString *ask = @"\n(E)ingabe, (S)uche, (L)iste oder (Q)uit?";
    char sel;
    
    while((sel = [IOHelper prompt:ask]) != 'q') {
        switch(sel) {
            case 'e':
                [self enterCard];
                break;
            case 's':
                [self lookupCard];
                break;
            case 'l':
                [self printBook];
                break;
        }
    }
    
    // TODO: write address book to file @"book.archive"
    
    
}

- (void)enterCard {
    [IOHelper printLineWithFormat:@"Neue Karte anlegen:"];
    // TODO: read in a new address card and add it to the book
}

- (void)lookupCard {
    NSString *searchName = [IOHelper readLineWithMessage:@"Suchname:"];
    
    // TODO: implement card search
    [IOHelper printLineWithFormat:@"Sie suchen nach '%@'.", searchName];
    
    // TODO: if card is found, ask what to do with current card
    NSString *ask = @"(F)reund/in hinzufügen, (L)öschen oder (Z)urück?";
    char sel;
    
    while((sel = [IOHelper prompt:ask]) != 'z') {
        // TODO: implement appropriate action
    }

}

- (void)printBook {
    // TODO: print out all cards
}

@end
